import { test, expect } from '../fixtures/evidence-test';
import { evidenceStep } from '../helpers/evidence';
import { AuthenticationFlow } from '../flows/authentication.flow';
import { SystemUserDashboardPage } from '../pages/system-user-dashboard.page';

const PROFILE = 'SUPER_USER_ADMIN_USER';
const TEST_ID = 'LIMAS-AUTH-022';

test.describe('LIMAS-AUTH-022: Page refresh session persistence', () => {
  test('should retain dashboard after page refresh', async ({ page, attachEvidencePlan, attachEvidenceResult }) => {
    const start = Date.now();
    let status: 'passed' | 'failed' = 'passed';
    let errorMessage: string | undefined;
    try {
      const { accessProfile } = await attachEvidencePlan(TEST_ID);
      const flow = new AuthenticationFlow(page);

      await evidenceStep(page, 'Authenticate and verify dashboard', '01', async () => {
        await flow.ensureAuthenticated(PROFILE);
        const dashboard = new SystemUserDashboardPage(page);
        await expect(dashboard.heading).toBeVisible();
      });

      await evidenceStep(page, 'Refresh page and verify session persists', '02', async () => {
        await page.reload();
        const dashboard = new SystemUserDashboardPage(page);
        await dashboard.waitForLoad();
        await expect(dashboard.heading).toBeVisible();
      });
    } catch (e: any) { status = 'failed'; errorMessage = e?.message ?? String(e); }
    finally { await attachEvidenceResult({ status, duration: Date.now() - start, errorMessage }); }
  });
});