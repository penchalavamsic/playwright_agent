import { Page } from '@playwright/test';
import { getCredentials } from '../helpers/auth';
import { LoginPage } from '../pages/login.page';
import { SystemUserDashboardPage } from '../pages/system-user-dashboard.page';

export class AuthenticationFlow {
  private loginPage: LoginPage;
  private dashboardPage: SystemUserDashboardPage;

  constructor(page: Page) {
    this.loginPage = new LoginPage(page);
    this.dashboardPage = new SystemUserDashboardPage(page);
  }

  async ensureAuthenticated(profileName: string): Promise<void> {
    await this.loginPage.goto();

    const alreadyLoggedIn = await this.dashboardPage.isDisplayed();
    if (alreadyLoggedIn) {
      return;
    }

    const { username, password } = getCredentials(profileName);

    await this.loginPage.clickSignIn();
    await this.loginPage.keycloakHeading.waitFor();

    await this.loginPage.fillCredentials(username, password);
    await this.loginPage.submitKeycloakLogin();

    await this.dashboardPage.waitForLoad();
  }
}