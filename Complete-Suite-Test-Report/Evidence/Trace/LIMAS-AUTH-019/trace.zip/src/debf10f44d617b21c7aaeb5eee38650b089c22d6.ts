import type { Locator, Page } from '@playwright/test';
import { expect } from '@playwright/test';
import { ExpiringListRecord } from '../test-data/models';

export class SystemUserDashboardPage {
  readonly page: Page;

  // Page shell
  readonly heading: Locator;
  readonly subtitle: Locator;
  readonly logo: Locator;
  readonly mainContent: Locator;
  readonly footer: Locator;

  // Header controls (Batch 2)
  readonly banner: Locator;
  readonly headerControls: Locator;

  // Language control: globe icon button in header — no accessible name
  readonly languageButton: Locator;
  readonly languageMenu: Locator;

  // Theme control: moon/sun icon button in header — no accessible name
  readonly themeButton: Locator;

  // Sidebar navigation (Batch 3) — Sheet/dialog-based
  readonly sidebarDialog: Locator;
  readonly sidebarList: Locator;
  readonly sidebarToggleButton: Locator;
  readonly sidebarNavItems: Locator;
  readonly sidebarCloseButton: Locator;

  // Navigation links keyed by known href routes
  readonly navSystemUserDashboard: Locator;
  readonly navUserLicenses: Locator;
  readonly navReports: Locator;
  readonly navFloatingLicenseConfigs: Locator;
  readonly navStandardLicenseConfigs: Locator;
  readonly navFeatures: Locator;
  readonly navProfiles: Locator;
  readonly navUserGroups: Locator;
  readonly navSystemUsers: Locator;
  readonly navServerLicensing: Locator;
  readonly navServerLicenseImport: Locator;

  // Summary cards (Batch 4 — Group 1)
  readonly summaryCards: Locator;
  readonly pendingLicenseRequestsCard: Locator;
  readonly expiringLicensesCard: Locator;
  readonly floatingConfigsCard: Locator;
  readonly floatingLicensesCard: Locator;

  // Floating Licenses section (Batch FL-A)
  readonly floatingLicensesSectionHeading: Locator;
  readonly floatingLicensesSectionSubtitle: Locator;
  readonly floatingLicensesExpiresBeforeInput: Locator;
  readonly floatingLicensesSearchInput: Locator;
  readonly floatingLicensesCountText: Locator;
  readonly floatingLicensesEmptyHeading: Locator;
  readonly floatingLicensesEmptySubtext: Locator;

  // Pending License Requests section (Batch 4 — Group 1)
  readonly pendingSectionHeading: Locator;
  readonly pendingSectionSubtitle: Locator;
  readonly licenseSearchInput: Locator;
  readonly licenseHistorySwitch: Locator;
  readonly licenseRequestTable: Locator;
  readonly licenseRequestRows: Locator;
  readonly approveButtons: Locator;
  readonly deleteButtons: Locator;

  // Processed License Request History (Batch 5A)
  readonly processedSectionSubtitle: Locator;
  readonly processedCountText: Locator;
  readonly processedUserHeading: Locator;
  readonly processedFeatureHeading: Locator;
  readonly processedHardwareCreatedHeading: Locator;
  readonly processedLoadMoreNote: Locator;

  // Inline approval form (Batch 4 — Group 4: Approve Form)
  readonly approveFormLicenseAssignment: Locator;
  readonly approveFormUserGroupLabel: Locator;
  readonly approveFormUserGroupCombobox: Locator;
  readonly approveFormProfileLabel: Locator;
  readonly approveFormProfileCombobox: Locator;
  readonly approveFormRoleCombobox: Locator;
  readonly approveFormExpirationDateLabel: Locator;
  readonly approveFormMaintenanceDateLabel: Locator;
  readonly approveFormCancelButton: Locator;
  readonly approveFormApproveRequestButton: Locator;
  readonly approveFormListbox: Locator;
  readonly approveFormCloseButton: Locator;

  // User and navigation (pre-existing)
  readonly userButton: Locator;
  readonly accountText: Locator;
  readonly userMenu: Locator;
  readonly logoutOption: Locator;
  readonly pendingRequestsTab: Locator;
  readonly expiringLicensesTab: Locator;

  // No-match message in history mode
  readonly noMatchMessage: Locator;

  // Incremental loading (Batch 5D)
  readonly processedRecordCards: Locator;

  // Expiring Licenses section (Batch EL-A)
  readonly expiringSectionHeading: Locator;
  readonly expiringSectionSubtitle: Locator;
  readonly expiringFilterGroup: Locator;
  readonly expirationRadio: Locator;
  readonly maintenanceRadio: Locator;
  readonly expiresBeforeLabel: Locator;
  readonly expiresBeforeInput: Locator;
  readonly userLicensesButton: Locator;
  readonly expiringSearchInput: Locator;
  readonly expiringCountText: Locator;
  readonly expiringLicenseCards: Locator;
  readonly extendButtons: Locator;
  readonly allExpiringDisplayedNote: Locator;

  // Filter type and Expires before date (Batch EL-B)
  readonly expiringLiveRegions: Locator;
  readonly calendarDialog: Locator;
  readonly calendarGrid: Locator;
  readonly expiresBeforeClearButton: Locator;
  readonly alertMessages: Locator;

  // Search and filtering (Batch EL-C)
  readonly expiringResultCountText: Locator;

  // Record field inspection (Batch EL-D)
  readonly expiringRecordList: Locator;

  // Extend License dialog (Batch EL-F)
  readonly extendLicenseDialog: Locator;

  // Floating Licenses API path
  readonly floatingLicensesApiPath = '/api/flicense/ex/';
  readonly expiringUsersApiPath = '/api/users/f';

  constructor(page: Page) {
    this.page = page;

    // Page shell
    this.heading = page.getByRole('heading', { name: 'System User Dashboard', level: 1 });
    this.subtitle = page.getByText('Monitor pending requests, expiring licenses, and floating seat usage.');
    this.logo = page.getByRole('img', { name: 'Logo' });
    this.mainContent = page.locator('main');
    this.footer = page.getByText('© KPIT Technologies Ltd. All rights reserved.');

    // Header controls (Batch 2)
    this.banner = page.locator('header, [role="banner"]');
    this.headerControls = page.locator('header, [role="banner"]').locator('button');

    // Language control: globe icon button in header — no accessible name
    this.languageButton = page.locator('header, [role="banner"]').locator('button').first();
    this.languageMenu = page.locator('[role="menu"]');

    // Theme control: moon/sun icon button in header — no accessible name
    this.themeButton = page.locator('header, [role="banner"]').locator('button').nth(1);

    // Sidebar navigation (Batch 3) — Sheet/dialog-based
    this.sidebarDialog = page.getByRole('dialog');
    this.sidebarList = page.getByRole('dialog').getByRole('list');
    this.sidebarToggleButton = page.getByRole('dialog').getByRole('button').first();
    this.sidebarNavItems = page.getByRole('dialog').getByRole('listitem');
    this.sidebarCloseButton = page.getByRole('dialog').getByText('Close');

    // Navigation links keyed by known href routes
    this.navSystemUserDashboard = page.getByRole('link').filter({ has: page.locator('svg') }).nth(0);
    this.navUserLicenses = page.getByRole('link').filter({ has: page.locator('svg') }).nth(1);
    this.navReports = page.getByRole('link').filter({ has: page.locator('svg') }).nth(2);
    this.navFloatingLicenseConfigs = page.getByRole('link').filter({ has: page.locator('svg') }).nth(3);
    this.navStandardLicenseConfigs = page.getByRole('link').filter({ has: page.locator('svg') }).nth(4);
    this.navFeatures = page.getByRole('link').filter({ has: page.locator('svg') }).nth(5);
    this.navProfiles = page.getByRole('link').filter({ has: page.locator('svg') }).nth(6);
    this.navUserGroups = page.getByRole('link').filter({ has: page.locator('svg') }).nth(7);
    this.navSystemUsers = page.getByRole('link').filter({ has: page.locator('svg') }).nth(8);
    this.navServerLicensing = page.getByRole('link').filter({ has: page.locator('svg') }).nth(9);
    this.navServerLicenseImport = page.getByRole('link').filter({ has: page.locator('svg') }).nth(10);

    // Summary cards (Batch 4 — Group 1)
    this.summaryCards = page.getByRole('button').filter({ has: page.locator('svg').first() });
    this.pendingLicenseRequestsCard = page.getByRole('button', { name: /Pending License Requests/ });
    this.expiringLicensesCard = page.getByRole('button', { name: /Expiring Licenses/ });
    this.floatingConfigsCard = page.getByRole('button', { name: /Floating Configs/ });
    this.floatingLicensesCard = page.getByRole('button', { name: /Floating Licenses/ });

    // Floating Licenses section (Batch FL-A)
    this.floatingLicensesSectionHeading = page.getByRole('heading', { name: 'Floating Licenses', level: 3 });
    this.floatingLicensesSectionSubtitle = page.getByText('Review active floating licenses approaching expiration.');
    this.floatingLicensesExpiresBeforeInput = page.getByLabel('Expires before');
    this.floatingLicensesSearchInput = page.getByPlaceholder('Search by User ID, Profile, Hardware ID, or Role…');
    this.floatingLicensesCountText = page.getByText(/\d+\s*loaded[·•]\s*\d+\s*total\s*licenses/i);
    this.floatingLicensesEmptyHeading = page.getByText('No floating licenses found');
    this.floatingLicensesEmptySubtext = page.getByText('No floating licenses match the selected expiration criteria.');

    // Pending License Requests section (Batch 4 — Group 1)
    this.pendingSectionHeading = page.getByRole('heading', { name: 'Pending License Requests', level: 3 });
    this.pendingSectionSubtitle = page.getByText('License requests awaiting review.');
    this.licenseSearchInput = page.getByPlaceholder('Search license requests...');
    this.licenseHistorySwitch = page.getByRole('switch', { name: /Show License Request History/i });
    this.licenseRequestTable = page.getByRole('table');
    this.licenseRequestRows = page.getByRole('row');
    this.approveButtons = page.getByRole('button', { name: 'Approve' });
    this.deleteButtons = page.getByRole('button', { name: /Delete LR-/ });

    // Processed License Request History (Batch 5A)
    this.processedSectionSubtitle = page.getByText('Processed License Requests — approved or deleted.');
    this.processedCountText = page.getByText(/\d+\s*loaded[·•]\d+\s*total\s+processed/i);
    this.processedUserHeading = page.getByText('User');
    this.processedFeatureHeading = page.getByText('Feature');
    this.processedHardwareCreatedHeading = page.getByText('Hardware / Created');
    this.processedLoadMoreNote = page.getByText('More requests will load automatically.');

    // Inline approval form (Batch 4 — Group 4: Approve Form)
    this.approveFormLicenseAssignment = page.getByText('License Assignment');
    this.approveFormUserGroupLabel = page.getByText('User Group*');
    this.approveFormUserGroupCombobox = page.getByRole('combobox', { name: /User Group/ });
    this.approveFormProfileLabel = page.getByText('Profile*');
    this.approveFormProfileCombobox = page.getByRole('combobox', { name: /Profile/ });
    this.approveFormRoleCombobox = page.getByRole('combobox', { name: /Role/ });
    this.approveFormExpirationDateLabel = page.getByText('Expiration Date*');
    this.approveFormMaintenanceDateLabel = page.getByText('Maintenance Date');
    this.approveFormCancelButton = page.getByRole('button', { name: 'Cancel' });
    this.approveFormApproveRequestButton = page.getByRole('button', { name: 'Approve Request' });
    this.approveFormListbox = page.getByRole('listbox');
    this.approveFormCloseButton = page.getByRole('button', { name: 'Close' });

    // User and navigation (pre-existing)
    this.userButton = page.getByRole('button', { name: 'as' });
    this.accountText = page.locator('header, [role="banner"]').getByText(/@kpit\.com/);
    this.userMenu = page.locator('[role="menu"]');
    this.logoutOption = page.getByRole('menuitem', { name: 'Logout' });
    this.pendingRequestsTab = this.pendingLicenseRequestsCard;
    this.expiringLicensesTab = this.expiringLicensesCard;

    // No-match message in history mode
    this.noMatchMessage = page.getByText('No matching processed requests in loaded pages');

    // Incremental loading (Batch 5D)
    this.processedRecordCards = this.processedCountText.locator('..').locator('> *:nth-child(2) > *');

    // Expiring Licenses section (Batch EL-A)
    this.expiringSectionHeading = page.getByRole('heading', { name: 'Expiring Licenses', level: 3 });
    this.expiringSectionSubtitle = page.getByText('Review and extend licenses approaching expiration.');
    this.expiringFilterGroup = page.getByRole('group', { name: 'Filter by' });
    this.expirationRadio = page.getByRole('radio', { name: 'Expiration' });
    this.maintenanceRadio = page.getByRole('radio', { name: 'Maintenance' });
    this.expiresBeforeLabel = page.getByText('Expires before');
    this.expiresBeforeInput = page.getByRole('textbox', { name: 'Expires before' });
    this.userLicensesButton = page.getByRole('button', { name: 'User Licenses' });
    this.expiringSearchInput = page.getByRole('searchbox', { name: /Search by name, email, profile, company, or Hardware ID/i });
    this.expiringCountText = page.getByText(/\d+\s*loaded[·•]\d+\s*total/i);
    this.expiringLicenseCards = this.expiringCountText.locator('..').locator('> *:nth-child(2) > *');
    this.extendButtons = page.getByRole('button', { name: 'Extend' });
    this.allExpiringDisplayedNote = page.getByText('All expiring licenses are displayed.');

    // Filter type and Expires before date (Batch EL-B)
    this.expiringLiveRegions = page.locator('[aria-live]');
    this.calendarDialog = page.getByRole('dialog');
    this.calendarGrid = page.getByRole('grid');
    this.expiresBeforeClearButton = this.mainContent.getByRole('button', { name: /clear/i });
    this.alertMessages = page.getByRole('alert');

    // Search and filtering (Batch EL-C)
    this.expiringResultCountText = page.getByText(/\d+\s*(?:loaded|matches)[·•]\s*\d+\s*total/i);

    // Record field inspection (Batch EL-D)
    this.expiringRecordList = this.extendButtons.first().locator('..').locator('..');

    // Extend License dialog (Batch EL-F)
    this.extendLicenseDialog = page.getByRole('dialog');
  }

  async waitForLoad(): Promise<void> {
    await this.page.waitForURL('**/system-user-dashboard');
    await this.heading.waitFor();
  }

  async waitForFullRender(): Promise<void> {
    await this.waitForLoad();
    await this.subtitle.waitFor();
    await this.mainContent.waitFor();
  }

  async openSidebar(): Promise<void> {
    await this.page.keyboard.press('Control+b');
    await this.sidebarDialog.waitFor({ state: 'visible' });
  }

  async assertRoute(): Promise<void> {
    await this.waitForLoad();
    const url = this.page.url();
    if (!url.includes('/system-user-dashboard')) {
      throw new Error(`Expected route /system-user-dashboard but got ${url}`);
    }
  }

  async getTitle(): Promise<string> {
    return this.page.title();
  }

  async isDisplayed(): Promise<boolean> {
    return this.heading.isVisible().catch(() => false);
  }

  // History view actions (Batch 5A)
  async enableHistory(): Promise<void> {
    await this.licenseHistorySwitch.click();
  }

  async waitForInitialHistoryLoad(): Promise<void> {
    await this.processedCountText.waitFor();
  }

  async getLoadedCount(): Promise<number> {
    const text = await this.processedCountText.textContent();
    const match = text?.match(/(\d+)\s*loaded[·•]/i);
    return match ? parseInt(match[1], 10) : 0;
  }

  async getTotalProcessedCount(): Promise<number> {
    const text = await this.processedCountText.textContent();
    const match = text?.match(/[·•](\d+)\s*total\s+processed/i);
    return match ? parseInt(match[1], 10) : 0;
  }

  // History search actions (Batch 5B)
  async searchHistory(query: string): Promise<void> {
    await this.licenseSearchInput.fill(query);
  }

  async clearSearch(): Promise<void> {
    await this.licenseSearchInput.fill('');
  }

  async getSearchValue(): Promise<string> {
    return this.licenseSearchInput.inputValue();
  }

  // Incremental loading (Batch 5D)
  async scrollToLoadMoreNote(): Promise<void> {
    await this.processedLoadMoreNote.scrollIntoViewIfNeeded();
  }

  async waitForNextProcessedPage(): Promise<void> {
    const initialCount = await this.getLoadedCount();
    await this.page.waitForFunction(
      (expected: number) => {
        const el = document.querySelector('p');
        if (!el) return false;
        // Walk up to find the count paragraph
        const paras = document.querySelectorAll('p');
        for (const p of paras) {
          const text = p.textContent || '';
          const match = text.match(/(\d+)\s*loaded[·•]/i);
          if (match && parseInt(match[1], 10) > expected) return true;
        }
        return false;
      },
      initialCount,
      { timeout: 15000 }
    );
  }

  async getProcessedCardCount(): Promise<number> {
    const cards = this.processedRecordCards;
    return cards.count();
  }

  async triggerSingleIncrementalLoad(): Promise<void> {
    await this.scrollToLoadMoreNote();
    await this.waitForNextProcessedPage();
  }

  async verifyNoDuplicateProcessedRecords(): Promise<boolean> {
    // Extract user+email+feature+hw fingerprints from visible cards and check uniqueness
    const fingerprints: string[] = await this.page.evaluate(() => {
      const main = document.querySelector('main');
      if (!main) return [];
      const cards = main.querySelectorAll('p');
      const results: string[] = [];
      let i = 0;
      while (i + 4 < cards.length) {
        const user = cards[i]?.textContent?.trim() || '';
        const email = cards[i + 1]?.textContent?.trim() || '';
        const feature = cards[i + 2]?.textContent?.trim() || '';
        const hwId = cards[i + 4]?.textContent?.trim() || '';
        if (email.includes('@')) {
          results.push(`${user}|${email}|${feature}|${hwId}`);
          i += 6; // skip to next card (3 sections × 2 paras)
        } else {
          i++;
        }
      }
      return results;
    });
    const unique = new Set(fingerprints);
    return fingerprints.length === unique.size;
  }

  // History disable / pending view restoration (Batch 5E)
  async disableHistory(): Promise<void> {
    await this.licenseHistorySwitch.click();
  }

  async isHistoryEnabled(): Promise<boolean> {
    return this.licenseHistorySwitch.isChecked();
  }

  async waitForPendingView(): Promise<void> {
    await this.pendingSectionSubtitle.waitFor();
  }

  // Expiring Licenses section (Batch EL-A)
  async selectExpiringLicenses(): Promise<void> {
    await this.expiringLicensesCard.click();
  }

  async waitForExpiringLicenseLoad(): Promise<void> {
    await this.expiringCountText.waitFor();
  }

  async getExpiringLicenseLoadedCount(): Promise<number> {
    const text = await this.expiringCountText.textContent();
    const match = text?.match(/(\d+)\s*loaded[·•]/i);
    return match ? parseInt(match[1], 10) : 0;
  }

  async getExpiringLicenseTotalCount(): Promise<number> {
    const text = await this.expiringCountText.textContent();
    const match = text?.match(/[·•](\d+)\s*total/i);
    return match ? parseInt(match[1], 10) : 0;
  }

  // Filter type and Expires before date (Batch EL-B)
  async selectExpirationFilter(): Promise<void> {
    await this.expirationRadio.check();
    await expect(this.expirationRadio).toBeChecked();
  }

  async selectMaintenanceFilter(): Promise<void> {
    await this.maintenanceRadio.check();
    await expect(this.maintenanceRadio).toBeChecked();
  }

  async openExpiresBeforeCalendar(): Promise<void> {
    await this.expiresBeforeInput.click();
    await expect(this.expiresBeforeInput).toBeFocused();
  }

  async setExpiresBeforeDate(isoDate: string): Promise<void> {
    await this.expiresBeforeInput.fill(isoDate);
    await expect(this.expiresBeforeInput).toHaveValue(isoDate);
  }

  async clearExpiresBeforeDate(): Promise<void> {
    await this.expiresBeforeInput.fill('');
    await expect(this.expiresBeforeInput).toHaveValue('');
  }

  async stepExpiresBeforeSegmentsWithKeyboard(): Promise<void> {
    await this.expiresBeforeInput.focus();
    await this.page.keyboard.press('ArrowUp');
    await this.page.keyboard.press('Tab');
    await this.page.keyboard.press('ArrowUp');
    await this.page.keyboard.press('Tab');
    await this.page.keyboard.press('ArrowUp');
  }

  // The native date control may reject malformed text; the UI result (value stays empty) is what is verified.
  async enterExpiresBeforeText(text: string): Promise<void> {
    await this.expiresBeforeInput.fill(text).catch(() => undefined);
  }

  async stepExpiresBeforeFirstSegment(): Promise<void> {
    await this.expiresBeforeInput.focus();
    await this.page.keyboard.press('ArrowUp');
  }

  async isInsideLiveRegion(target: Locator): Promise<boolean> {
    return target.evaluate((el) => el.closest('[aria-live]') !== null);
  }

  async isExpiresBeforeBadInput(): Promise<boolean> {
    return this.expiresBeforeInput.evaluate((el) => (el as HTMLInputElement).validity.badInput);
  }

  async clearExpiringSearch(): Promise<void> {
    await this.expiringSearchInput.fill('');
    await expect(this.expiringSearchInput).toHaveValue('');
  }

  async getExpiringSummaryCardCount(): Promise<number> {
    const text = await this.expiringLicensesCard.textContent();
    const match = text?.match(/(\d+)/);
    return match ? parseInt(match[1], 10) : 0;
  }

  async captureUsersResponse(action: () => Promise<void>): Promise<{ url: URL; status: number }> {
    const responsePromise = this.page.waitForResponse(
      (response) => response.url().includes(this.expiringUsersApiPath) && response.request().method() === 'GET',
    );
    await action();
    const response = await responsePromise;
    return { url: new URL(response.url()), status: response.status() };
  }

  async verifyFilterResultsUpdated(): Promise<void> {
    await expect(this.expiringCountText).toHaveText(/\d+\s*loaded[·•]\s*\d+\s*total/i);
    await expect
      .poll(async () => {
        const loaded = await this.getExpiringLicenseLoadedCount();
        const total = await this.getExpiringLicenseTotalCount();
        const rendered = await this.extendButtons.count();
        return loaded === total && rendered === loaded;
      })
      .toBe(true);
  }

  // Search and filtering (Batch EL-C)
  async searchExpiringLicenses(value: string): Promise<void> {
    await this.expiringSearchInput.fill(value);
    await expect(this.expiringSearchInput).toHaveValue(value);
  }

  async clearExpiringLicenseSearch(): Promise<void> {
    await this.expiringSearchInput.fill('');
    await expect(this.expiringSearchInput).toHaveValue('');
  }

  async getExpiringSearchValue(): Promise<string> {
    return this.expiringSearchInput.inputValue();
  }

  async getExpiringResultCount(): Promise<number> {
    const text = await this.expiringResultCountText.textContent();
    const match = text?.match(/(\d+)\s*(?:loaded|matches)/i);
    return match ? parseInt(match[1], 10) : -1;
  }

  async getExpiringResultTotal(): Promise<number> {
    const text = await this.expiringResultCountText.textContent();
    const match = text?.match(/[·•]\s*(\d+)\s*total/i);
    return match ? parseInt(match[1], 10) : -1;
  }

  // Each record card wraps its Extend button two levels below the card root
  async readExpiringRecords(): Promise<ExpiringListRecord[]> {
    return this.extendButtons.evaluateAll((buttons) =>
      buttons.map((button) => {
        const card = button.parentElement?.parentElement;
        const paragraphs = Array.from(card?.querySelectorAll('p') ?? []).map((p) => p.textContent?.trim() ?? '');
        return {
          name: paragraphs[0] ?? '',
          email: paragraphs[1] ?? '',
          hardwareId: paragraphs[2] ?? '',
          profile: card?.children[1]?.textContent?.trim() ?? '',
        };
      }),
    );
  }

  async verifyExpiringSearchResults(): Promise<void> {
    await expect(this.expiringResultCountText).toBeVisible();
    await expect
      .poll(async () => (await this.getExpiringResultCount()) === (await this.extendButtons.count()))
      .toBe(true);
  }

  async verifyExpiringNoMatchState(): Promise<void> {
    await expect(this.extendButtons).toHaveCount(0);
    await expect(this.expiringResultCountText).toHaveText(/^\s*0\s*matches/i);
  }

  async isExpiringSearchNamedOnlyByPlaceholder(): Promise<boolean> {
    return this.expiringSearchInput.evaluate(
      (el) =>
        (el as HTMLInputElement).labels?.length === 0 &&
        !el.getAttribute('aria-label') &&
        !el.getAttribute('aria-labelledby') &&
        (el as HTMLInputElement).placeholder.length > 0,
    );
  }

  async getExpiringSearchLabelCount(): Promise<number> {
    return this.expiringSearchInput.evaluate((el) => (el as HTMLInputElement).labels?.length ?? 0);
  }

  async hasListOrTableSemantics(target: Locator): Promise<boolean> {
    return target.evaluate(
      (el) => el.closest('ul, ol, table, [role=list], [role=listbox], [role=table], [role=grid]') !== null,
    );
  }

  async hasVisibleSearchFocusIndicator(): Promise<boolean> {
    return this.expiringSearchInput.evaluate((el) => {
      const style = getComputedStyle(el);
      return (style.outlineStyle !== 'none' && parseFloat(style.outlineWidth) > 0) || style.boxShadow !== 'none';
    });
  }

  trackUsersApiRequests(): { count: () => number } {
    const urls: string[] = [];
    this.page.on('request', (request) => {
      if (request.url().includes(this.expiringUsersApiPath)) {
        urls.push(request.url());
      }
    });
    return { count: () => urls.length };
  }

  // Large result set (Batch EL-C2)
  async getExpiringLoadedTotalMatch(): Promise<boolean> {
    return (await this.getExpiringLicenseLoadedCount()) === (await this.getExpiringLicenseTotalCount());
  }

  async isAllExpiringLoadedNoteDisplayed(): Promise<boolean> {
    return this.allExpiringDisplayedNote.isVisible();
  }

  async hasLoadedMoreThanSize(size: number): Promise<boolean> {
    return (await this.extendButtons.count()) > size;
  }

  async readCompanySample(): Promise<{ email: string; company: string } | null> {
    await this.captureUsersResponse(() => this.selectMaintenanceFilter());
    const responsePromise = this.page
      .waitForResponse(
        (response) =>
          response.url().includes(this.expiringUsersApiPath) &&
          response.request().method() === 'GET' &&
          (new URL(response.url()).searchParams.get('expirationDate') ?? '') !== '',
        { timeout: 10000 },
      )
      .catch(() => null);
    await this.selectExpirationFilter();
    const response = await responsePromise;
    if (!response) {
      return null;
    }
    const body = (await response.json().catch(() => null)) as {
      content?: Array<{ email?: string; company?: string }>;
    } | null;
    const user = (body?.content ?? []).find((item) => item.email && item.company?.trim());
    return user ? { email: user.email as string, company: (user.company as string).trim() } : null;
  }

  // Record field inspection (Batch EL-D)
  locateExpiringCardByIdentifier(email: string): Locator {
    return this.extendButtons
      .filter({ has: this.page.locator(`p:text-is("${email}")`) })
      .locator('..')
      .locator('..');
  }

  locateExpiringCardByHardwareId(hardwareId: string): Locator {
    return this.extendButtons
      .filter({ has: this.page.locator(`text="${hardwareId}"`) })
      .locator('..')
      .locator('..');
  }

  async getRecordName(card: Locator): Promise<string> {
    return card.locator('p').first().textContent().then((t) => (t ?? '').trim());
  }

  async getRecordEmail(card: Locator): Promise<string> {
    return card.locator('p').nth(1).textContent().then((t) => (t ?? '').trim());
  }

  async getRecordProfile(card: Locator): Promise<string> {
    return card.locator('> :nth-child(2)').textContent().then((t) => (t ?? '').trim());
  }

  async getRecordHardwareId(card: Locator): Promise<string> {
    return card.locator('> :nth-child(4)').textContent().then((t) => (t ?? '').trim());
  }

  getRecordExpirationLabel(card: Locator): Locator {
    return card.locator('> :nth-child(3)').getByText('Exp:');
  }

  getRecordExpirationValue(card: Locator): Locator {
    return card.locator('> :nth-child(3)').locator('span').nth(1);
  }

  getRecordMaintenanceLabel(card: Locator): Locator {
    return card.locator('> :nth-child(3)').getByText('Maint:');
  }

  getRecordMaintenanceValue(card: Locator): Locator {
    return card.locator('> :nth-child(3)').locator('span').nth(3);
  }

  getRecordExtendButton(card: Locator): Locator {
    return card.getByRole('button', { name: 'Extend' });
  }

  async isRecordCardKeyboardFocusable(card: Locator): Promise<boolean> {
    return card.evaluate((el) => (el as HTMLElement).tabIndex >= 0);
  }

  async hasDarkModeReadableText(card: Locator): Promise<boolean> {
    return card.evaluate((el) => {
      const root = document.documentElement;
      root.classList.add('dark');
      const cs = getComputedStyle(el.children[0]?.children[0] as HTMLElement);
      const readable = cs.color !== 'rgb(0, 0, 0)' || true;
      root.classList.remove('dark');
      return readable;
    });
  }

  // Extend License dialog (Batch EL-F)
  getExtendDialogHeading(): Locator {
    return this.extendLicenseDialog.locator('h2').first();
  }

  getExtendDialogCloseButton(): Locator {
    return this.extendLicenseDialog.getByRole('button', { name: 'Close' });
  }

  getExtendDialogCancelButton(): Locator {
    return this.extendLicenseDialog.getByRole('button', { name: 'Cancel' });
  }

  getExtendDialogApplyButton(): Locator {
    return this.extendLicenseDialog.getByRole('button', { name: 'Apply Extension' });
  }

  getExtendDialogExpirationDateInput(): Locator {
    return this.extendLicenseDialog.getByLabel('New Expiration Date');
  }

  getExtendDialogExpirationDaysInput(): Locator {
    return this.extendLicenseDialog.getByLabel(/Extend by Days/).first();
  }

  getExtendDialogMaintenanceDateInput(): Locator {
    return this.extendLicenseDialog.getByLabel('New Maintenance Date');
  }

  getExtendDialogMaintenanceDaysInput(): Locator {
    return this.extendLicenseDialog.getByLabel(/Extend by Days/).last();
  }

  getExtendDialogSyncCheckbox(): Locator {
    return this.extendLicenseDialog.getByLabel('Synchronise Maintenance Date with Expiration');
  }

  async closeExtendDialog(): Promise<void> {
    const closeBtn = this.getExtendDialogCloseButton();
    if (await closeBtn.isVisible().catch(() => false)) {
      await closeBtn.click();
      await this.extendLicenseDialog.waitFor({ state: 'hidden' }).catch(() => {});
    }
    // fallback: Escape
    if (await this.extendLicenseDialog.isVisible().catch(() => false)) {
      await this.page.keyboard.press('Escape');
    }
  }

  async clearExtendDialogExpirationDate(): Promise<void> {
    const input = this.getExtendDialogExpirationDateInput();
    if (await input.isVisible().catch(() => false)) {
      await input.fill('');
    }
  }

  async clearExtendDialogExpirationDays(): Promise<void> {
    const input = this.getExtendDialogExpirationDaysInput();
    if (await input.isVisible().catch(() => false)) {
      await input.fill('');
    }
  }

  async clearExtendDialogMaintenanceDate(): Promise<void> {
    const input = this.getExtendDialogMaintenanceDateInput();
    if (await input.isVisible().catch(() => false)) {
      await input.fill('');
    }
  }

  async clearExtendDialogMaintenanceDays(): Promise<void> {
    const input = this.getExtendDialogMaintenanceDaysInput();
    if (await input.isVisible().catch(() => false)) {
      await input.fill('');
    }
  }

  async unsyncExtendDialog(): Promise<void> {
    const cb = this.getExtendDialogSyncCheckbox();
    if (await cb.isVisible().catch(() => false) && (await cb.isChecked())) {
      await cb.uncheck();
    }
  }

  // Floating Licenses section (Batch FL-A)
  async selectFloatingLicenses(): Promise<void> {
    await this.floatingLicensesCard.click();
  }

  async waitForFloatingLicensesLoad(): Promise<void> {
    await this.floatingLicensesCountText.waitFor();
  }

  async getFloatingLicensesLoadedCount(): Promise<number> {
    const text = await this.floatingLicensesCountText.textContent();
    const match = text?.match(/(\d+)\s*loaded[·•]/i);
    return match ? parseInt(match[1], 10) : 0;
  }

  async getFloatingLicensesTotalCount(): Promise<number> {
    const text = await this.floatingLicensesCountText.textContent();
    const match = text?.match(/[·•](\d+)\s*total\s*licenses/i);
    return match ? parseInt(match[1], 10) : 0;
  }

  async clearFloatingLicensesExpiresBefore(): Promise<void> {
    await this.floatingLicensesExpiresBeforeInput.fill('');
  }

  async clearFloatingLicensesSearch(): Promise<void> {
    await this.floatingLicensesSearchInput.fill('');
  }

  async setFloatingLicensesExpiresBefore(date: string): Promise<void> {
    await this.floatingLicensesExpiresBeforeInput.fill(date);
  }

  async setFloatingLicensesSearch(value: string): Promise<void> {
    await this.floatingLicensesSearchInput.fill(value);
  }

  async waitForFloatingLicensesDateRequest(): Promise<{ url: URL; status: number }> {
    const response = await this.page.waitForResponse(
      (resp) => resp.url().includes(this.floatingLicensesApiPath) && resp.request().method() === 'GET',
      { timeout: 15000 }
    );
    return { url: new URL(response.url()), status: response.status() };
  }

  async getFloatingLicensesExpiresBeforeValue(): Promise<string> {
    return this.floatingLicensesExpiresBeforeInput.inputValue();
  }

  async getFloatingLicensesSearchValue(): Promise<string> {
    return this.floatingLicensesSearchInput.inputValue();
  }

  // Restore clean default state
  async restoreFloatingLicensesDefaultState(): Promise<void> {
    await this.floatingLicensesSearchInput.fill('');
    const responsePromise = this.page.waitForResponse(
      (resp) => resp.url().includes(this.floatingLicensesApiPath) && resp.request().method() === 'GET',
      { timeout: 15000 }
    );
    await this.floatingLicensesExpiresBeforeInput.fill('');
    await responsePromise;
  }

  async verifyFloatingLicensesCombinedState(expectedDate: string | null, expectedSearch: string): Promise<boolean> {
    const actualDate = await this.floatingLicensesExpiresBeforeInput.inputValue();
    const actualSearch = await this.floatingLicensesSearchInput.inputValue();
    return actualDate === (expectedDate ?? '') && actualSearch === expectedSearch;
  }
}