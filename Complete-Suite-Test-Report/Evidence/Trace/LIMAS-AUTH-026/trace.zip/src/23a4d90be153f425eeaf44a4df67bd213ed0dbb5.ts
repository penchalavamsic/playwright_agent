import { test, expect } from '../fixtures/evidence-test';
import { evidenceStep } from '../helpers/evidence';
import { AuthenticationFlow } from '../flows/authentication.flow';
import { SystemUserDashboardPage } from '../pages/system-user-dashboard.page';

const PROFILE = 'SUPER_USER_ADMIN_USER';
const TEST_ID = 'LIMAS-AUTH-026';

test.describe('LIMAS-AUTH-026: User button visibility after login', () => {
  test('should display user identity button in header after login', async ({ page, attachEvidencePlan, attachEvidenceResult }) => {
    const start = Date.now();
    let status: 'passed' | 'failed' = 'passed';
    let errorMessage: string | undefined;
    try {
      const { accessProfile } = await attachEvidencePlan(TEST_ID);
      const flow = new AuthenticationFlow(page);
      await evidenceStep(page, 'Authenticate via Keycloak login', '01', async () => {
        await flow.ensureAuthenticated(PROFILE);
      });
      await evidenceStep(page, 'Verify user identity button in header', '02', async () => {
        const dashboard = new SystemUserDashboardPage(page);
        await expect(dashboard.userButton).toBeVisible();
      });
    } catch (e: any) { status = 'failed'; errorMessage = e?.message ?? String(e); }
    finally { await attachEvidenceResult({ status, duration: Date.now() - start, errorMessage }); }
  });
});