import { Page, test as base } from '@playwright/test';
import fs from 'fs';
import path from 'path';

interface EvidenceStepOptions {
  /** If true, capture a full-page screenshot. Default: viewport only. */
  fullPage?: boolean;
}

/**
 * Run a named test.step that captures a screenshot after execution and attaches it to the step.
 * Captures on both success and failure (when the page is available).
 */
export async function evidenceStep(
  page: Page,
  stepName: string,
  orderPrefix: string,
  fn: () => Promise<void>,
  options: EvidenceStepOptions = {},
): Promise<void> {
  const screenshotName = `${orderPrefix}-${stepName.replace(/[^a-zA-Z0-9-]/g, '-').toLowerCase()}.png`;

  await base.step(stepName, async () => {
    try {
      await fn();
    } finally {
      try {
        const buffer = await page.screenshot({ fullPage: options.fullPage ?? false });
        await base.info().annotations.push({ type: 'screenshot', description: screenshotName });
        // Attach to this step
        await base.info().attach(screenshotName, { body: buffer, contentType: 'image/png' });
      } catch {
        // Page may be closed — skip screenshot
      }
    }
  });
}

/**
 * Build an evidence summary markdown attachment.
 */
export function buildEvidenceSummary(params: {
  testId: string;
  module: string;
  accessProfile: string;
  purpose: string;
  preconditions: string;
  expectedResult: string;
  specPath: string;
  planPath: string;
}): string {
  return [
    `# Test: ${params.testId}`,
    '',
    `**Module:** ${params.module}`,
    `**Access Profile:** ${params.accessProfile}`,
    `**Spec:** ${params.specPath}`,
    `**Plan:** ${params.planPath}`,
    '',
    '## Purpose',
    params.purpose,
    '',
    '## Preconditions',
    params.preconditions,
    '',
    '## Expected Result',
    params.expectedResult,
  ].join('\n');
}

/**
 * Build an actual result attachment after test completion.
 */
export function buildActualResult(params: {
  status: 'passed' | 'failed';
  duration: number;
  finalRoute: string;
  errorMessage?: string;
}): string {
  const lines = [
    '# Actual Result',
    '',
    `**Status:** ${params.status}`,
    `**Duration:** ${(params.duration / 1000).toFixed(2)}s`,
    `**Final Route:** ${params.finalRoute}`,
  ];
  if (params.status === 'passed') {
    lines.push('', 'All assertions completed successfully.');
  }
  if (params.errorMessage) {
    lines.push('', '## Error', `\`\`\`\n${params.errorMessage}\n\`\`\``);
  }
  return lines.join('\n');
}

/**
 * Build a sanitized API/navigation summary.
 */
export function buildApiSummary(summary: {
  method: string;
  pathname: string;
  status: number;
  trigger: string;
  redirects?: string[];
}): string {
  const lines = [
    '# API / Navigation Summary',
    '',
    `**Method:** ${summary.method}`,
    `**Pathname:** ${summary.pathname}`,
    `**Status:** ${summary.status}`,
    `**Trigger:** ${summary.trigger}`,
  ];
  if (summary.redirects && summary.redirects.length > 0) {
    lines.push(`**Redirects:** ${summary.redirects.join(' → ')}`);
  }
  return lines.join('\n');
}

/**
 * Resolve a relative spec path from the current test file.
 */
export function getSpecRelativePath(testFilename: string): string {
  const testsDir = path.resolve(__dirname, '..');
  const relative = path.relative(testsDir, testFilename);
  return relative.replace(/\\/g, '/');
}