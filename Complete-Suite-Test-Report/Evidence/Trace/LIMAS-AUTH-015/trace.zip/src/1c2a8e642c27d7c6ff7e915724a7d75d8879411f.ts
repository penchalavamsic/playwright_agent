import { test as base, expect } from '@playwright/test';
import {
  resolveAuthPlan,
  parsePlanFrontmatter,
  extractPlanPurpose,
  extractPlanPreconditions,
  extractPlanExpectedResult,
} from '../helpers/test-plan-resolver';
import {
  buildEvidenceSummary,
  buildActualResult,
  buildApiSummary,
  getSpecRelativePath,
} from '../helpers/evidence';

interface EvidenceFixtures {
  /**
   * Call once at the start of a test to attach the plan, summary, and annotations.
   * Returns metadata for use in the test body.
   */
  attachEvidencePlan: (testId: string) => Promise<{
    accessProfile: string;
    module: string;
    planPath: string;
  }>;
  /**
   * Call at the end of a test to attach the actual result, final screenshot, and API summary.
   */
  attachEvidenceResult: (params: {
    status: 'passed' | 'failed';
    duration: number;
    errorMessage?: string;
    apiSummary?: string;
  }) => Promise<void>;
}

export const test = base.extend<EvidenceFixtures>({
  attachEvidencePlan: async ({ page }, use, testInfo) => {
    const fn = async (testId: string) => {
      const { planPath, content } = resolveAuthPlan(testId);
      const fm = parsePlanFrontmatter(content);
      const accessProfile = fm['access_profile'] ?? 'SUPER_USER_ADMIN_USER';
      const module = fm['module'] ?? 'Authentication';

      // Attach the plan file itself
      await testInfo.attach('Atomic Test Plan', {
        path: planPath,
        contentType: 'text/markdown',
      });

      // Annotations
      testInfo.annotations.push({ type: 'module', description: module });
      testInfo.annotations.push({ type: 'accessProfile', description: accessProfile });
      testInfo.annotations.push({ type: 'testId', description: testId });
      testInfo.annotations.push({ type: 'evidenceMode', description: 'detailed' });
      testInfo.annotations.push({ type: 'planPath', description: planPath.replace(/\\/g, '/') });

      // Evidence summary
      const specPath = getSpecRelativePath(testInfo.file);
      const summary = buildEvidenceSummary({
        testId,
        module,
        accessProfile,
        purpose: extractPlanPurpose(content),
        preconditions: extractPlanPreconditions(content),
        expectedResult: extractPlanExpectedResult(content),
        specPath,
        planPath: planPath.replace(/\\/g, '/'),
      });
      await testInfo.attach('Test Summary', {
        body: summary,
        contentType: 'text/markdown',
      });

      return { accessProfile, module, planPath };
    };
    await use(fn);
  },

  attachEvidenceResult: async ({ page }, use, testInfo) => {
    const fn = async (params: {
      status: 'passed' | 'failed';
      duration: number;
      errorMessage?: string;
      apiSummary?: string;
    }) => {
      // Actual result
      const finalRoute = page.url().split('?')[0] ?? '(page closed)';
      const actualResult = buildActualResult({
        status: params.status,
        duration: params.duration,
        finalRoute,
        errorMessage: params.errorMessage,
      });
      await testInfo.attach('Actual Result', {
        body: actualResult,
        contentType: 'text/markdown',
      });

      // Final screenshot
      try {
        const buffer = await page.screenshot({ fullPage: false });
        await testInfo.attach('Final Screenshot', {
          body: buffer,
          contentType: 'image/png',
        });
      } catch {
        // page closed
      }

      // API summary if provided
      if (params.apiSummary) {
        await testInfo.attach('API / Navigation Summary', {
          body: params.apiSummary,
          contentType: 'text/markdown',
        });
      }
    };
    await use(fn);
  },
});

export { expect };