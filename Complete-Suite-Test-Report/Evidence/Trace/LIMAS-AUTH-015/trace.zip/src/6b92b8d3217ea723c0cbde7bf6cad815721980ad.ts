import type { Locator, Page } from '@playwright/test';

export class LoginPage {
  readonly page: Page;
  readonly signInButton: Locator;
  readonly kpitLogo: Locator;
  readonly limasLogo: Locator;
  readonly copyrightNotice: Locator;

  // Keycloak elements (available after clicking Sign In)
  readonly keycloakHeading: Locator;
  readonly usernameField: Locator;
  readonly passwordField: Locator;
  readonly showPasswordButton: Locator;
  readonly keycloakSignInButton: Locator;

  constructor(page: Page) {
    this.page = page;

    this.signInButton = page.getByRole('button', { name: 'Sign In' });
    this.kpitLogo = page.getByRole('img', { name: 'KPIT Logo' });
    this.limasLogo = page.getByRole('img', { name: 'LIMAS Logo' });
    this.copyrightNotice = page.getByText('© KPIT Technologies Ltd. All rights reserved.');

    this.keycloakHeading = page.getByRole('heading', { name: 'Sign in to your account', level: 1 });
    this.usernameField = page.getByRole('textbox', { name: 'Username or email' });
    this.passwordField = page.getByRole('textbox', { name: 'Password' });
    this.showPasswordButton = page.getByRole('button', { name: 'Show password' });
    this.keycloakSignInButton = page.getByRole('button', { name: 'Sign In' });
  }

  async goto(): Promise<void> {
    await this.page.goto('/');
  }

  async clickSignIn(): Promise<void> {
    await this.signInButton.click();
    await this.page.waitForURL(/realms\/LIMAS\/protocol\/openid-connect\/auth/);
  }

  async fillCredentials(username: string, password: string): Promise<void> {
    await this.usernameField.fill(username);
    await this.passwordField.fill(password);
  }

  async submitKeycloakLogin(): Promise<void> {
    await this.keycloakSignInButton.click();
  }
}