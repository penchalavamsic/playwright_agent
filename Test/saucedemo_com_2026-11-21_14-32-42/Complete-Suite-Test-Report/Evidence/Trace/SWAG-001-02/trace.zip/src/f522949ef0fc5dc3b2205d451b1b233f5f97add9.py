"""Live End-to-End Self-Test against https://www.saucedemo.com into E:\\MySpace\\Projects\\playwright_agent\\Test."""

import asyncio
import os
import re
import sys
from pathlib import Path

sys.path.insert(0, r"E:\MySpace\Projects\playwright_agent")

from agents.state import AgentState
from agents.workflow_graph import run_agent_pipeline


async def main() -> int:
    base_test_dir = Path(r"E:\MySpace\Projects\playwright_agent\Test").resolve()
    base_test_dir.mkdir(parents=True, exist_ok=True)

    initial_state: AgentState = {
        "target_url": "https://www.saucedemo.com",
        "user_flow_text": (
            "Login as standard user, add to cart Sauce Labs Backpack, "
            "click shopping-cart-link to open cart and verify checkout UI and 200 status"
        ),
        "target_languages": ["Python", "Java", "TypeScript", "JavaScript"],
        "output_dir": str(base_test_dir),
        "headless": False,
        "generate_test_plan": True,
        "generate_scripts": True,
        "interactive_mode": False,
        "active_access_profile": "STANDARD_USER",
        "account_credentials": {
            "STANDARD_USER": {
                "username": "standard_user",
                "password": "secret_sauce",
            }
        },
        "sequence_number": 1,
        "parsed_flow_steps": [],
        "inspection_report": {},
        "test_plan_markdown": "",
        "test_scenarios": [],
        "generated_files": [],
        "errors": [],
    }

    print("Running live Playwright pipeline against https://www.saucedemo.com (headless=False)...")
    final_state = await run_agent_pipeline(initial_state)

    resolved_dir = Path(final_state["output_dir"]).resolve()
    print(f"\nResolved Workspace Folder: {resolved_dir}")

    passed = 0
    failed = 0

    def check(cond: bool, msg: str) -> None:
        nonlocal passed, failed
        if cond:
            passed += 1
            print(f"  [PASS] {msg}")
        else:
            failed += 1
            print(f"  [FAIL] {msg}")

    # 1. Verify folder name matches saucedemo_com_<YYYY-MM-DD_HH-MM-SS>
    check(
        resolved_dir.parent == base_test_dir and bool(re.match(r"^saucedemo_com_\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}$", resolved_dir.name)),
        f"Folder matches saucedemo_com_<timestamp>: {resolved_dir.name}",
    )

    # 2. Verify all 4 languages, docs, .env, and Complete-Suite-Test-Report exist
    for expected in (
        ".env",
        ".env.example",
        "access-profiles.json",
        ".qa_studio_project.json",
        "docs/Test_Plan_IEEE829.md",
        "Complete-Suite-Test-Report/index.html",
        "Complete-Suite-Test-Report/report-summary.json",
        "Python_Playwright/conftest.py",
        "Java_Playwright/src/test/java/com/corp/qa/tests/BaseTest.java",
        "TypeScript_Playwright/playwright.config.ts",
        "JavaScript_Playwright/playwright.config.js",
    ):
        check((resolved_dir / expected).exists(), f"Exists: {expected}")

    # 3. Verify ZERO LIMAS strings anywhere in resolved_dir
    leaks = []
    text_exts = {".env", ".example", ".json", ".md", ".html", ".txt", ".py", ".java", ".ts", ".js", ".xml", ".ini"}
    for f in resolved_dir.rglob("*"):
        if f.is_file() and (f.suffix.lower() in text_exts or f.name in (".env", ".env.example", ".gitignore")):
            txt = f.read_text(encoding="utf-8", errors="ignore")
            if "limas" in txt.lower():
                leaks.append(str(f.relative_to(resolved_dir)))
    check(len(leaks) == 0, f"ZERO 'LIMAS' leaks across all generated files (leaks={leaks})")

    # 4. Verify real PNG (>10 KB), playable video.webm (>5 KB), and trace.zip
    ev_dir = resolved_dir / "Complete-Suite-Test-Report" / "Evidence"
    pngs = list((ev_dir / "Screenshots").rglob("*.png"))
    webms = list((ev_dir / "Recording").rglob("video.webm"))
    traces = list((ev_dir / "Trace").rglob("trace.zip"))

    min_png = min((p.stat().st_size for p in pngs), default=0)
    max_png = max((p.stat().st_size for p in pngs), default=0)
    webm_size = webms[0].stat().st_size if webms else 0
    trace_size = traces[0].stat().st_size if traces else 0

    check(len(pngs) >= 2 and min_png > 10_000, f"Real PNG screenshots (>10 KB): count={len(pngs)}, min={min_png:,}B, max={max_png:,}B")
    check(len(webms) >= 1 and webm_size > 5_000, f"Real playable video.webm (>5 KB): {webm_size:,}B")
    check(len(traces) >= 1 and trace_size > 1_000, f"Real trace.zip: {trace_size:,}B")

    report = final_state.get("inspection_report", {})
    check(bool(report.get("login_performed")), f"Auto-login succeeded on saucedemo.com (probes={report.get('probes_executed')})")

    print("\n" + "=" * 80)
    print(f"LIVE SAUCEDEMO SELF-TEST: {passed} PASSED, {failed} FAILED")
    print(f"REPORT_HTML={resolved_dir / 'Complete-Suite-Test-Report' / 'index.html'}")
    print("=" * 80)
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
